package classes

import jakarta.persistence.*
import org.hibernate.annotations.OnDelete
import org.hibernate.annotations.OnDeleteAction

@Entity
@Table(name = "punt", schema = "public")
open class Punt {
    @EmbeddedId
    open var id: PuntId? = null

    @MapsId("numR")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "num_r", nullable = false, insertable = false, updatable = false)
    open var numR: Ruta? = null

    @Column(name = "nom_p", length = Integer.MAX_VALUE)
    open var nomP: String? = null

    @Column(name = "latitud")
    open var lat: Float? = null

    @Column(name = "longitud")
    open var long: Float? = null
}