package classes

import jakarta.persistence.Column
import jakarta.persistence.Embeddable
import org.hibernate.Hibernate
import java.io.Serializable
import java.util.*

@Embeddable
open class PuntId : Serializable {
    @Column(name = "num_r", nullable = false)
    open var numR: Int? = null

    @Column(name = "num_p", nullable = false)
    open var numP: Int? = null
    override fun hashCode(): Int = Objects.hash(numR, numP)
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || Hibernate.getClass(this) != Hibernate.getClass(other)) return false

        other as PuntId

        return numR == other.numR &&
                numP == other.numP
    }

    companion object {
        private const val serialVersionUID = -8696513725792617374L
    }
}