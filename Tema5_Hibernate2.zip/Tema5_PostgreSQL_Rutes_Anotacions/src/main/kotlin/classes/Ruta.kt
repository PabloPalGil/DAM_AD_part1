package classes

import jakarta.persistence.*

@Entity
@Table(name = "ruta", schema = "public")
open class Ruta {
    @Id
    @Column(name = "num_r", nullable = false)
    open var id: Int? = null

    @Column(name = "nom_r", length = Integer.MAX_VALUE)
    open var nomR: String? = null

    @Column(name = "desnivell")
    open var desnivell: Int? = null

    @Column(name = "desnivell_acumulat")
    open var desnivellAcumulat: Int? = null

    @OneToMany(mappedBy = "numR")
    @OrderBy("id ASC") // Orden ascendente por el número de puntos
    open var punts: MutableSet<Punt> = mutableSetOf()
}