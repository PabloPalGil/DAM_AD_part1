package exercicis

import classes.Ruta
import org.hibernate.cfg.Configuration
import java.util.logging.Level
import java.util.logging.LogManager


fun main(args: Array<String>) {
    //Evitamos sacar por pantalla molestos logs
    LogManager.getLogManager().getLogger("").setLevel(Level.SEVERE)

    //Creamos la sesión a través del SessionFactory:
    val sessio = Configuration().configure().buildSessionFactory().openSession()

    //Como sólo queremos consultar datos, no necesitamos abrir ninguna transacción
    //Creamos la variable q para asignar las rutas que nos devuelva la BD tras nuestra consulta:
    val q = sessio.createQuery("from Ruta order by nomR", Ruta::class.java)

    //Recorremos cada ruta devuelta
    for(r in q.list()) {
        println(r.nomR + " - " + r.punts.size + " punts")
        //Recorremos cada punto de la ruta
        for (p in r.punts) {
            println(p.nomP)
        }
        println()
    }

    //Cerramos la sesión:
    sessio.close()
}