package Ejemplos

import java.io.*

fun main(args: Array<String>) {
    val f_ent = InputStreamReader(FileInputStream("f5.txt"), "UTF-8")
    //val f_ent = FileReader("f5.txt")
    val f_eix = OutputStreamWriter(FileOutputStream("f5_ISO.txt"), "ISO-8859-1")

    var car = f_ent.read()
    while (car != -1) {
        f_eix.write(car)
        car = f_ent.read()
    }
    f_eix.close()
    f_ent.close()
}