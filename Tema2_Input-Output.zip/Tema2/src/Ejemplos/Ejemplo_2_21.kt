package Ejemplos

import java.io.FileReader

fun main(args: Array<String>){
    val f_in = FileReader("f1.txt") //Cambiamos FileInputStream (Bytes) por FileReader (Chars)
    var c = f_in.read()
    while (c!=-1){
        println(c.toChar())
        c = f_in.read()
    }
    f_in.close()
}

//ANÁLOGAMENTE A LOS FLUJOS ORIENTADOS A BYTES (EJEMPLOS ANTERIORES), LOS SIGUIENTES EJEMPLOS,
//QUE UTILIZAN FLUJOS ORIENTADOS A CARACTERES, SE DEBEN UTILIZAR CUANDO LOS DATOS SON TEXTO, YA QUE
//RESUELVEN DE FORMA TRANSPARENTE AL PROGRAMADOR LA CODIFICACIÓN DEL TEXTO (ASCII, UTF-8, UTF-16, ETC)
//LA ANALOGÍA ES TAL QUE ASÍ:
//BYTES -> InputStream / OutputStream
//CHARS -> Reader / Writer