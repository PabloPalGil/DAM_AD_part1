package Ejemplos

import java.io.FileInputStream
import java.io.FileOutputStream

fun main(args: Array<String>) {
    val f_in = FileInputStream("f2.txt")
    val f_out = FileOutputStream("f4.txt")

    var buffer = ByteArray(30)
    var num = f_in.read(buffer)
    while (num != -1) {
        //f_out.write(buffer)    // açò és un error (si no consigues leer 30 caracteres (final de contenido),
        //los que faltan serán los de la última lectura
        f_out.write(buffer,0,num)     // ara sí que funcionarà bé (hay que escribir los bytes leidos
        // realmente, no los bytes máximos del buffer).
        num = f_in.read(buffer)
    }
    f_in.close();
    f_out.close();//MUY IMPORTANTE CERRAR SIEMPRE LOS FLUJOS/STREAMS DE SALIDA
}