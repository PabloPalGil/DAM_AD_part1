package Ejercicios

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class FitxerImatge(fEnt: File) {
    var f: File = File("")   // No modifiqueu aquesta línia. El seu valor s'ha de modificar en el constructor

    init {
        // Constructor
        // Control d'existència del fitxer i control de l'extensió .bmp (traure missatges d'error)
        if(fEnt.exists()){
            if(fEnt.name.endsWith("bmp") && fEnt.extension == "bmp"){
                // En cas que tot siga correcte, inicialitzar f amb fEnt
                f = fEnt
            } else {
                println("Error: no es un archivo .bmp")
            }
        } else {
            println("Error: no se encuentra el archivo.")
        }
    }

    fun transformaNegatiu() {
        // Transformar a negatiu i guardar en _n.bmp
        val f_in = FileInputStream(f)
        val f_out = FileOutputStream(f.nameWithoutExtension + "_n.bmp")

        //Los primeros 54 bytes los copiamos tal cual porque son metadatos
        copyMetaDataBmp(f_in, f_out)

        //Ahora transformamos cada pixel en negativo
        var byte = f_in.read() //Leemos de byte en byte
        while(byte != -1) {
            f_out.write(255 - byte)//Esto nos da el color RGB negativo
            byte = f_in.read()
        }
        println("Imagen negativa " + f.nameWithoutExtension + "_n" + " creada con éxito.")
        
        //Cerramos los flujos
        f_in.close()
        f_out.close()
    }

    private fun copyMetaDataBmp(f_in: FileInputStream, f_out: FileOutputStream) {
        val bmpFormatBytes = ByteArray(54)
        var byte = f_in.read(bmpFormatBytes)
        f_out.write(bmpFormatBytes, 0, byte)
    }

    fun transformaObscur() {
        // Transformar a una imatge més fosca i guardar en _o.bmp
        val f_in = FileInputStream(f)
        val f_out = FileOutputStream(f.nameWithoutExtension + "_o.bmp")

        //Los primeros 54 bytes los copiamos tal cual porque son metadatos
        copyMetaDataBmp(f_in, f_out)

        //Ahora transformamos cada pixel para oscurecerlo
        var byte = f_in.read() //Leemos de byte en byte
        while(byte != -1) {
            f_out.write(byte / 2)//Esto nos da el color RGB con la mitad de brillo
            byte = f_in.read()
        }
        println("Imagen oscura " + f.nameWithoutExtension + "_o" + " creada con éxito.")

        //Cerramos los flujos
        f_in.close()
        f_out.close()
    }

    // Part voluntària
    fun transformaBlancNegre() {
        // Transformar a una imatge en blanc i negre i guardar en _bn.bmp
        val f_in = FileInputStream(f)
        val f_out = FileOutputStream(f.nameWithoutExtension + "_bn.bmp")

        //Los primeros 54 bytes los copiamos tal cual porque son metadatos
        copyMetaDataBmp(f_in, f_out)

        var byte = f_in.read() //Leemos de byte en byte
        //Para obtener un pixel en blanco y negro deberemos homogeneizar cada pixel (3 Bytes consecutivos) a gris
        var r = 0//Rojo
        var g  = 0//Verde
        var b  = 0//Azul

        while(byte != -1) {
            r = byte
            byte = f_in.read()
            g = byte
            byte = f_in.read()
            b = byte

            byte = (r + g + b) / 3 //Esto nos da el color RGB en escala de grises
            for(i in 1..3){
                f_out.write(byte)//Escribimos los 3 componentes de cada pixel con el gris obtenido
            }
            byte = f_in.read()//Leemos el siguiente pixel
        }
        println("Imagen en blanco y negro " + f.nameWithoutExtension + "_bn" + " creada con éxito.")

        //Cerramos los flujos
        f_in.close()
        f_out.close()
    }

}