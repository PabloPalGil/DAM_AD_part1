package exemples

import classes.Comarca
import org.hibernate.cfg.Configuration
import java.util.logging.Level
import java.util.logging.LogManager

fun main(args: Array<String>) {
    LogManager.getLogManager().getLogger("").setLevel(Level.SEVERE)
    val sessio = Configuration().configure().buildSessionFactory().openSession()
    val q = sessio.createQuery ("from Comarca", Comarca::class.java)

    val llista = q.list()

    val it = llista.iterator()
    while (it.hasNext()) {
        val com = it.next() // no fa falta fer un casting perquè ja sap que és Comarca
        println(com.nomC + " - " + com.provincia)
    }
    sessio.close()
}