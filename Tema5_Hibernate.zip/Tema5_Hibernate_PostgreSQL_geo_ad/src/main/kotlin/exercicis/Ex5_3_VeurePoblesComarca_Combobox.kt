package exercicis

import java.awt.EventQueue
import java.awt.BorderLayout
import java.awt.FlowLayout
import java.awt.Color
import javax.swing.JFrame
import javax.swing.JPanel
import javax.swing.JLabel
import javax.swing.JTextField
import javax.swing.JScrollPane
import javax.swing.JComboBox
import javax.swing.DefaultListModel
import javax.swing.JList
import classes.Comarca
import classes.Poblacio
import org.hibernate.cfg.Configuration
import java.util.logging.Level
import java.util.logging.LogManager

class FinestraComboBox : JFrame() {
    val etiqueta = JLabel("Comarca:")
    val etIni = JLabel("Introdueix la comarca:")
    val com = JComboBox<String>()
    val listModel = DefaultListModel<String>()
    val area = JList(listModel)
    val peu = JTextField()

    val sessio = Configuration().configure().buildSessionFactory().openSession()

    init {
        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        setTitle("HIBERNATE: Visualitzar Comarques i Pobles amb ComboBox")
        setBounds(100, 100, 550, 400)
        setLayout(BorderLayout())

        val panell1 = JPanel(FlowLayout())
        panell1.add(etIni)
        panell1.add(com)
        getContentPane().add(panell1, BorderLayout.NORTH)

        val panell2 = JPanel(BorderLayout())
        panell2.add(etiqueta, BorderLayout.NORTH)
        area.setForeground(Color.blue)
        val scroll = JScrollPane(area)
        panell2.add(scroll, BorderLayout.CENTER)
        getContentPane().add(panell2, BorderLayout.CENTER)
        getContentPane().add(peu, BorderLayout.SOUTH)

        agafarComarques()

        com.addActionListener() { visualitzaCom(com.getSelectedItem().toString()) }

        area.addListSelectionListener() {
            if (!area.isSelectionEmpty())
                visualitzaInstituts(area.getSelectedValue())
            else
                peu.setText("")
        }
    }

    fun agafarComarques() {
        // Instruccions per a posar en el ComboBox el nom de totes les comarques, millor si és per ordre alfabètic

        //Consultamos los nombres de las comarcas:
        val q = sessio.createQuery ("select nomC from Comarca", String::class.java)

        //Recorremos cada comarca:
        for (c in q.list()) {
            com.addItem(c)//Añadimos el nombre de la comarca al ComboBox
        }
    }

    fun visualitzaCom(comarca: String) {
        // Instruccions per a llegir la comarca que arriba com a paràmetre (s'ha de deixar en un objecte Comarca).
        // S'ha de cuidar que si no exiteix la comarca, en el JList es pose que no existeix.
        // La manera d'anar introduint informació en el JList és a través del DefaultListModel:
        // listModel.addElement("Linia que es vol introduir ")
        // Per a esborrar els element del JList: listModel.clear()
        // Es pot fer carregant un objecte, o per mig de consulta, però en aquest cas podem tenir problemes amb '
        // Una manera de solucionar el problema de la cometa simple és utilitzar comarca.replaceAll("'","''").
        // Una altra és utilitzar paràmetres

        //Como sólo queremos consultar datos, no necesitamos abrir ninguna transacción
        //Consultamos los pueblos de la comarca pasada (con parámetros):
        val q = sessio.createQuery ("from Poblacio where comarca.nomC = ?1 order by nom", Poblacio::class.java)
        q.setParameter(1, comarca)

        val pueblos = q.list()

        listModel.clear() //Vacíamos la lista

        //Asumimos que la comarca existe si devuelve al menos un pueblo:
        if (pueblos.isNotEmpty()) {
            //Recorremos los pueblos
            for (p in pueblos) {
                listModel.addElement(p.nom) //Añadimos el nombre del pueblo al JList
            }
        } else { //Si la comarca no existe
            listModel.addElement("La comarca no existeix.")
        }
    }

    fun visualitzaInstituts(poble: String) {
        // Instruccions per a mostrar el número d'Instituts del poble seleccionat
        // La millor manera és per mig d'una consulta. Podem tenir problemes amb la cometa simple
        // Una manera de solucionar el problema de la cometa simple és utilitzar poble.replaceAll("'","''").
        // Una altra és utilitzar paràmetres

        //Consultamos los institutos del pueblo pasado (usando parámetros):
        val q = sessio.createQuery("select count(i.codi) from Poblacio p left join p.instituts i where p.nom = ?1",
            Integer::class.java)
        q.setParameter(1, poble)

        //El resultado siempre será 1 número entero
        val instituts = q.list()

        peu.setText(poble + ": " + instituts[0] + " instituts")
    }
}

fun main() {
    EventQueue.invokeLater {
        FinestraComboBox().isVisible = true
    }
}