package classes

import jakarta.persistence.*

@Entity
@Table(name = "institut")
class Institut {
    @Id
    @Column(name = "codi", nullable = false, length = 8)
    var codi: String? = null

    @Column(name = "adreca", length = 100)
    var adreca: String? = null

    @Column(name = "codpostal")
    var codpostal: Int? = null

    @Column(name = "nom", length = 60)
    var nom: String? = null

    @Column(name = "numero", length = 5)
    var numero: String? = null

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cod_m")
    var codM: Poblacio? = null
}