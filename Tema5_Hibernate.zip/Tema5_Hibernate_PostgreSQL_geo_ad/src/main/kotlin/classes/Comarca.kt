package classes

import jakarta.persistence.*

@Entity
@Table(name = "comarca")
class Comarca {
    @Id
    @Column(name = "nom_c", nullable = false, length = 50)
    var nomC: String? = null

    @Column(name = "provincia", length = 25)
    var provincia: String? = null

    @Column(name = "nombre")
    var nombre: String? = null

    @OneToMany(mappedBy = "comarca")
    @OrderBy("nom") //Orden alfabético por nombre de pueblos
    var poblacions: MutableCollection<Poblacio> = mutableSetOf()
}