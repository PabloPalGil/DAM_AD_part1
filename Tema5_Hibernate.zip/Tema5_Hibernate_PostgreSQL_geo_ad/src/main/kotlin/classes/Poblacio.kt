package classes

import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = "poblacio")
class Poblacio {
    @Id
    @Column(name = "cod_m", nullable = false, precision = 5)
    var id: BigDecimal? = null

    @Column(name = "nom", nullable = false, length = 50)
    var nom: String? = null

    @Column(name = "poblacio", precision = 6)
    var poblacio: Float? = null

    @Column(name = "extensio", precision = 6, scale = 2)
    var extensio: BigDecimal? = null

    @Column(name = "altura", precision = 4)
    var altura: BigDecimal? = null

    @Column(name = "longitud", length = 50)
    var longitud: String? = null

    @Column(name = "latitud", length = 50)
    var latitud: String? = null

    @Column(name = "llengua")
    var llengua: String? = null

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "nom_c")
    var comarca: Comarca? = null

    @OneToMany(mappedBy = "codM")
    var instituts: MutableSet<Institut> = mutableSetOf()
}