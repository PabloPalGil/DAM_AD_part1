package Ejercicios
//NOTA: como en el tema 3 mi package era "Ejercicios", he refactorizado a "Ejercicios" en el Tema 4 también
//para poder importar el fichero Rutes.obj sin mayor complicación.

import util.bd.Ruta
import java.io.EOFException
import java.io.FileInputStream
import java.io.ObjectInputStream
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.sql.Statement

fun main(args: Array<String>) {
    //Leemos del fichero Rutes.obj y vamos trasladando la información a la base de datos Rutes.sqlite
    //Abrimos el flujo para leer de Rutes.obj
    val f = ObjectInputStream(FileInputStream("Rutes.obj"))

    //Creamos una lista de Rutas que usaremos para crear la instancia de Rutes
    var listaRutas = arrayListOf<Ruta>()

    //Como Rutes.obj contiene los objetos Ruta serilizables, recuperamos los objetos directamente
    try {
        while (true) {
            //Vamos leyendo las rutas y creamos un listado
            val ruta = f.readObject() as Ruta
            listaRutas.add(ruta)
        }
    } catch (eof: EOFException) {
        f.close()
    }

    //En este punto ya tenemos el listado de rutas en listaRutas
    //Procedemos a conectar con Rutes.sqlite
    var con: Connection? = null
    val st: Statement? = null

    try {
        //Intentamos la conexión al SGBD (SQLite)
        val url = "jdbc:sqlite:Rutes.sqlite"
        con = DriverManager.getConnection(url)

        println("Conexión con la base de datos SQLite realizada con éxito.")


        //Ahora, para cada ruta, vamos insertando la información desglosada por columnas en cada tabla de la bbdd:
        for(i in 0..listaRutas.lastIndex){
            //Tabla RUTES:
            //Columna num_r (clave principal, INTEGER)
            val numR = i + 1

            //Columna nom_r (TEXT)
            val nomR = listaRutas[i].nom

            //Columna desn (INTEGER)
            val desniv = listaRutas[i].desnivell

            //Columna desn_ac (INTEGER)
            val desnivAc = listaRutas[i].desnivellAcumulat

            //Definimos la sentencia SQL, que para mayor comodidad será con parámetros:
            //Al ser con parámetros, definimos la sentencia en el momento de su definición:
            val st = con.prepareStatement("INSERT INTO RUTES VALUES (?, ?, ?, ?);")

            //Definimos los parámetros antes de su ejecución:
            //Parámetros de la tabla RUTES
            st.setInt(1, numR)
            st.setString(2, nomR)
            st.setInt(3, desniv)
            st.setInt(4, desnivAc)

            //Comprobamos que la sintaxis es correcta:
            //println(st)

            //Finalmente, ejecutamos la sentencia:
            val rs = st.executeUpdate()

            //Insertamos cada punto de cada ruta:
            for(j in 0..listaRutas[i].llistaDePunts.lastIndex){
                //Tabla PUNTS:
                //Columna num_p (INTEGER)
                val numP = j + 1

                //Columna nom_p (TEXT)
                val nomP = listaRutas[i].llistaDePunts[j].nom

                //Columna latitud (REAL)
                val lat = listaRutas[i].llistaDePunts[j].coord.latitud

                //Columna longitud (REAL)
                val long = listaRutas[i].llistaDePunts[j].coord.longitud

                val st = con.prepareStatement("INSERT INTO PUNTS (num_r, num_p, nom_p, latitud, longitud)" +
                        "VALUES (?, ?, ?, ?, ?);")

                //Parámetros de la tabla PUNTS
                st.setInt(1, numR)
                st.setInt(2, numP)
                st.setString(3, nomP)
                st.setDouble(4, lat)
                st.setDouble(5, long)

                //Comprobamos que la sintaxis es correcta:
                //println(st)

                //Ejecutamos la sentencia:
                val rs = st.executeUpdate()
            }
        }

        println("Sentencias de inserción realizadas con éxito")

    } catch (e: SQLException) {
        println("Error: ${e.message}")
    } finally {
        st?.close()
        con?.close()
    }
}