package Ejercicios

import javax.swing.JFrame
import java.awt.EventQueue
import java.awt.BorderLayout
import javax.swing.JPanel
import java.awt.FlowLayout
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.sql.Statement
import javax.swing.JComboBox
import javax.swing.JButton
import javax.swing.JTextArea
import javax.swing.JLabel

class Finestra : JFrame() {

    init {
        // Sentències per a fer la connexió

        //Conectamos con Rutes.sqlite
        var con: Connection? = null
//        val st: Statement? = null

        try {
            //Intentamos la conexión al SGBD (SQLite)
            val url = "jdbc:sqlite:Rutes.sqlite"
            con = DriverManager.getConnection(url)

            defaultCloseOperation = JFrame.EXIT_ON_CLOSE
            setTitle("JDBC: Visualitzar Rutes")
            setSize(450, 450)
            setLayout(BorderLayout())

            val panell1 = JPanel(FlowLayout())
            val panell2 = JPanel(BorderLayout())
            add(panell1, BorderLayout.NORTH)
            add(panell2, BorderLayout.CENTER)

            val llistaRutes = arrayListOf<String>()
            // Sentències per a omplir l'ArrayList amb el nom de les rutes

            //Hacemos una consulta SQL que nos devuelva un listado de las rutas:
            //Creamos el statement (al no ser con parámetros, implementamos la sentencia SQL en su ejecución):
            val st = con.createStatement()

            //Definimos la sentencia SQL
            val sentSQL = "SELECT nom_r FROM RUTES"

            //Ejecutamos la sentencia:
            val rs = st.executeQuery(sentSQL)

            //Como sólo hemos solicitado los nombres de las rutas, añadimos la columna 1 (y única) a llistaRutes
            while(rs.next()) {
                llistaRutes.add(rs.getString(1))
            }

            //Cerramos esta sentencia
            st.close()

            val combo = JComboBox<String>(llistaRutes.toTypedArray())
            panell1.add(combo)
            val eixir = JButton("Eixir")
            panell1.add(eixir)
            val area = JTextArea()
            panell2.add(JLabel("Llista de punts de la ruta:"),BorderLayout.NORTH)
            panell2.add(area,BorderLayout.CENTER)


            combo.addActionListener() {
                // Sentèncis quan s'ha seleccionat un element del JComboBox
                // Han de consistir en omplir el JTextArea

                //Hacemos una consulta SQL que nos devuelva un listado de los puntos para la ruta seleccionada:
                //Definimos la sentencia SQL con parámetros:
                //Al ser con parámetros, definimos la sentencia en el momento de su definición:
                val st = con.prepareStatement("select * from PUNTS where num_r = ?")

                //Parámetro que indica qué ruta se ha seleccionado:
                st.setInt(1, combo.getSelectedIndex() + 1)

                //Ejecutamos la sentencia:
                val rs = st.executeQuery()

                //Aquí almacenaremos el texto a mostrar en el JTextArea
                var infoPuntos = ""

                //Trasladamos la información de cada punto (cada línea del rs):
                while(rs.next()) {
                    infoPuntos += "" + rs.getString(3) + " (" + rs.getDouble(4) + ", " +
                            "" + rs.getDouble(5) + ")\n"
                }

                //Ponemos el texto en el JTextArea
                area.text = infoPuntos

                //Cerramos esta sentencia
                st.close()
            }

            eixir.addActionListener(){
                // Sentències per a tancar la connexió i eixir

                try {
                    if (con != null && !con.isClosed()) {
                        con.close()
                    }
                } catch (ex: SQLException) {
                    throw ex
                } finally{
                    System.exit(0) //Cerramos la aplicación
                }
            }
        } catch (e: SQLException) {
            println("Error: ${e.message}")
        }
    }
}

fun main(args: Array<String>) {
    EventQueue.invokeLater {
        Finestra().isVisible = true
    }
}