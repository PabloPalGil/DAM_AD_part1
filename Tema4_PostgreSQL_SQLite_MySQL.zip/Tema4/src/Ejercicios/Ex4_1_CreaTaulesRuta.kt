package Ejercicios

import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.sql.Statement

fun main(args: Array<String>) {
    var con: Connection? = null
    val st: Statement? = null

    try {
        //Intentamos la conexión al SGBD (SQLite)
        val url = "jdbc:sqlite:Rutes.sqlite" //Si no existe el archivo, lo creará
        con = DriverManager.getConnection(url)

        println("Conexión con la base de datos SQLite realizada con éxito.")

        //Creamos el statement (al no ser con parámetros, implementamos la sentencia SQL en su ejecución):
        val st = con.createStatement()

        //Definimos la sentencia SQL
        val sentSQL = "CREATE TABLE RUTES(" +
                "num_r INTEGER CONSTRAINT cp_rut PRIMARY KEY, " +
                "nom_r TEXT, " +
                "desn INTEGER, " +
                "desn_ac INTEGER" +
                ");" +
                "CREATE TABLE PUNTS(" +
                "num_r INTEGER CONSTRAINT ce_punts_rutes references RUTES(num_r), " +
                "num_p INTEGER, " +
                "nom_p TEXT, " +
                "latitud REAL, " +
                "longitud REAL," +
                "CONSTRAINT cp_punts_rutes PRIMARY KEY (num_r, num_p)" +
                ");"

        //Ejecutamos la sentencia:
        st.executeUpdate(sentSQL)

        println("Sentencia realizada con éxito")

    } catch (e: SQLException) {
        println("Error: ${e.message}")
    } finally {
        st?.close()
        con?.close()
    }
}
