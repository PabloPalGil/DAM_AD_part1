package Ejercicios

import java.io.*

fun main(args: Array<String>) {
    val f = DataInputStream(FileInputStream("Rutes.dat"))

    //Leemos en bloques de rutas hasta que no encontramos nada que leer:
    while (f.available() > 0) {
        System.out.println("Ruta: " + f.readUTF())
        System.out.println("Desnivell: " + f.readInt())
        System.out.println("Desnivell acumulat: " + f.readInt())

        //Guardamos el número de puntos de la ruta
        val punts = f.readInt()
        System.out.println("Té $punts punts")

        //Ahora leemos la información de cada punto:
        for (i in 1..punts) {
            println("Punt ${i}: ${f.readUTF()} (${f.readDouble()},${f.readDouble()})")
        }
        System.out.println()
    }
    f.close()
}


//NOTA: usaremos DataInputStream/ DataOutputStream decorando a (File)InputStream / (File)OutputStream
// y los métodos readInt / writeInt o readUTF / writeUTF() cuando tengamos que hacer
// lectura/escritura secuencial y conozcamos la estructura del archivo de antemano.

//Si no fuera secuencial, tendríamos que utilizar RandomAccessFile(file, r/rw), pero igualmente necesitamos
//conocer la estructura del archivo.