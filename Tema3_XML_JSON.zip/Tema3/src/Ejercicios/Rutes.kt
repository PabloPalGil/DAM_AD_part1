package Ejercicios

class Rutes(var rutes: MutableList<Ruta> = mutableListOf<Ruta>())