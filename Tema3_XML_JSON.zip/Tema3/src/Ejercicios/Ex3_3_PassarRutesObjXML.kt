package Ejercicios

import java.io.EOFException
import java.io.FileInputStream
import java.io.ObjectInputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

fun main(args: Array<String>) {
    //Abrimos el flujo para leer de Rutes.obj
    val f = ObjectInputStream(FileInputStream ("Rutes.obj"))

    //Creamos el DOM de la estructura XML
    val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument()
    val arrel = doc.createElement ("rutes") //El elemento raíz o Documento es rutes
    doc.appendChild(arrel) //Añadimos la raíz a nuestro DOM vacío

    //EN teoría desconocemos la longitud del contenido de Rutes.obj, así que implementamos
    //un try-catch para terminar al llegar al final del fichero:
    try {
        while (true) {
            //Vamos leyendo las rutas y colgando su contenido en nuestro DOM:
            //r es la siguiente Ruta que leemos de Rutes.obj
            val r = f.readObject () as Ruta

            //ruta es el elemento que iremos completando y colgaremos en el DOM
            val ruta = doc.createElement ("ruta")

            //Creamos el elemento hijo "nom" de esta ruta:
            val nom = doc.createElement ("nom")
            //Forma larga de crear nodo de texto: crear un elemento hijo de tipo textNode con su contenido
            nom.appendChild(doc.createTextNode(r.nom))
            ruta.appendChild(nom)//Añadimos el nodo nom a esta ruta del DOM

            //Creamos el elemento hijo "desnivell" de esta ruta:
            val desn = doc.createElement("desnivell")
            //Forma corta de crear el nodo de texto: con setTextContent() con su contenido como String
            desn.setTextContent(r.desnivell.toString())
            ruta.appendChild(desn)//Añadimos el nodo desnivell a esta ruta del DOM

            //Creamos el elemento hijo "desnivellAcumulat" de esta ruta:
            val desnAcum = doc.createElement("desnivellAcumulat")
            desnAcum.setTextContent(r.desnivellAcumulat.toString())
            ruta.appendChild(desnAcum)//Añadimos el nodo desnivellAcumulat a esta ruta del DOM

            //punts es el elemento del DOM que contendrá cada punto de esta ruta
            val punts = doc.createElement ("punts")

            //tenemos que rellenar punts con cada punto:
            for (i in 0..r.llistaDePunts.size - 1) {
                //Primero creamos el elemento "punt"
                val punt = doc.createElement("punt")
                //Que tiene como atributo el índice dentro de la lista de puntos de la ruta:
                punt.setAttribute("num", Integer.toString(i + 1))

                //Creamos el primer elemento hijo de este punto: nom
                val pNom = doc.createElement("nom")
                pNom.setTextContent(r.llistaDePunts[i].nom)//TextNode de "nom" del punto
                punt.appendChild(pNom)//Añadimos el nodo "nom" a este "punt" del DOM

                //Creamos el segundo elemento hijo de este punto: latitud
                val lat = doc.createElement("latitud")
                lat.setTextContent(r.llistaDePunts[i].coord.latitud.toString())//TextNode de "latitud" del punto
                punt.appendChild(lat)//Añadimos el nodo "latitud" a este "punt" del DOM

                //Creamos el tercer elemento hijo de este punto: longitud
                val lon = doc.createElement("longitud")
                lon.setTextContent(r.llistaDePunts[i].coord.longitud.toString())//TextNode de "longitud" del punto
                punt.appendChild(lon)//Añadimos el nodo "longitud" a este "punt" del DOM

                //Una vez completado el contenido del punto, colgamos el elemento "punt" como hijo del elemento "punts" del DOM
                punts.appendChild(punt)
            }
            //Una vez hemos completado todos los puntos, sólo queda colgar el elemento "punts" al DOM:
            ruta.appendChild(punts)

            //Ahora ya tenemos el elemento de esta "ruta" completado, sólo queda añadirlo como hijo de "rutes"
            arrel.appendChild(ruta)
        }
    } catch (eof: EOFException) {
        f.close();
    }

    //En este punto ya tenemos el DOM completo y sólo quedará crear el fichero xml a partir del DOM
    val trans = TransformerFactory.newInstance().newTransformer()

    //Con las siguientes líneas le daremos un aspecto anidado, con 4 espacios:
    trans.setOutputProperty(OutputKeys.INDENT, "yes")
    trans.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4")

    //Creamos "Rutes.xml":
    trans.transform(DOMSource(doc), StreamResult("Rutes.xml"))
}