package Ejercicios

import com.squareup.moshi.*
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.ObjectInputStream

fun main (args: Array<String>){
    //Tenemos que construir la clase Rutes a partir del fichero Rutes.obj y luego generar el JSON
    //Abrimos el flujo para leer de Rutes.obj
    val f = ObjectInputStream(FileInputStream("Rutes.obj"))

    //Creamos una lista de Rutas que usaremos para crear la instancia de Rutes
    var listaRutas = arrayListOf<Ruta>()

    //Como Rutes.obj contiene los objetos Ruta serilizables, recuperamos los objetos directamente
    try {
        while (true) {
            //Vamos leyendo las rutas y creamos un listado
            val ruta = f.readObject() as Ruta
            listaRutas.add(ruta)
        }
    } catch (eof: EOFException) {
        f.close()
    }

    //Creamos nuestra instancia de Rutes:
    val rutes = Rutes(listaRutas)

    //Ya sólo queda utilizar las funciones de Moshi para crear el fichero Rutes.json:
    val moshi = Moshi.Builder().build() //Instanciamos el builder moshi
    //Instanciamos el adapter
    val adapter = moshi.adapter(Rutes::class.java).indent("  ") //Definimos aquí el anidado con 2 espacios con .indent()
    val json = adapter.toJson(rutes)

    File("Rutes.json").writeText(json)//Creamos el fichero Rutes.json
}