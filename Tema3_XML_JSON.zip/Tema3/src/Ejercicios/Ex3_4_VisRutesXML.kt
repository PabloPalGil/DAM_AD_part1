package Ejercicios

import javax.swing.*
import java.awt.*
import org.w3c.dom.Document
import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory


class Finestra : JFrame() {

    init {
        var doc: Document
        // sentències per a omplir doc
        doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse("Rutes.xml")

        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        setTitle("Punts d'una ruta")
        setSize(400, 300)
        setLayout(BorderLayout())

        val panell1 = JPanel(FlowLayout())
        val panell2 = JPanel(BorderLayout())
        add(panell1,BorderLayout.NORTH)
        add(panell2,BorderLayout.CENTER)

        val llistaRutes = arrayListOf<String>()
        // sentències per a omplir l'ArrayList anterior amb el nom de les rutes
        val arrel = doc.getDocumentElement()  //Referenciamos el elemento raíz ("rutes")

        //Cogemos los elementos "ruta" (este méttodo devuelve una lista)
        val listaDeRutas = arrel.getElementsByTagName("ruta")

        //Recorremos cada ruta para hallar sus nombres:
        for (i in 0 until listaDeRutas.length) {
            val r = listaDeRutas.item(i) as Element
            llistaRutes.add(r.getElementsByTagName("nom").item(0).getTextContent())
        }


        val combo = JComboBox(llistaRutes.toArray())
        panell1.add(combo)

        panell2.add(JLabel("Llista de punts de la ruta:"),BorderLayout.NORTH)
        val area = JTextArea()
        panell2.add(area)

        combo.addActionListener{
            // accions quan s'ha seleccionat un element del combobox,
            // i que han de consistir en omplir el JTextArea
            //Tenemos que acceder a cada hijo del elemento "punts" de la ruta seleccionada

            var infoPuntos = "" //Aquí almacenaremos el texto a mostrar en el JTextArea

            //Referenciamos la ruta cuyos puntos nos interesan:
            val ruta = arrel.getElementsByTagName("ruta").item(combo.getSelectedIndex()) as Element

            //Referenciamos el elemento punts de la ruta:
            val puntos = ruta.getElementsByTagName("punts").item(0) as Element

            //Referenciamos la lista de puntos que nos interesan:
            val listaPuntos = puntos.getElementsByTagName("punt")

            //Recorremos cada punto y vamos recopilando la información a mostrar en infoPuntos
            for (i in 0 until listaPuntos.length) {
                val p = listaPuntos.item(i) as Element
                infoPuntos += p.getElementsByTagName("nom").item(0).getTextContent() + " "
                infoPuntos += "(" + p.getElementsByTagName("latitud").item(0).getTextContent() + ","
                infoPuntos += p.getElementsByTagName("longitud").item(0).getTextContent() + ")\n"
            }
            //En este punto ya tenemos todos los puntos en infoPuntos y solo queda mostrarlo en el JTextArea:
            area.text = infoPuntos
        }
    }
}

fun main(args: Array<String>) {
    EventQueue.invokeLater {
        Finestra().isVisible = true
    }
}