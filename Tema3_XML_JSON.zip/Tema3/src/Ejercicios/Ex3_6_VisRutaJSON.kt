package Ejercicios

import javax.swing.*
import java.awt.*
import com.squareup.moshi.Moshi
import java.io.File

class FinestraJSON : JFrame() {

    init {
        var llistaRutes: ArrayList<Ruta>
        // sentències per a omplir llistaRutes
        //Indicamos el fichero de origen
        val json = File("Rutes.json").readText()

        val moshi = Moshi.Builder().build() //Instanciamos el builder de Moshi

        //Construimos el adapter indicando que queremos parsear una instancia de la clase Rutes
        val adapter = moshi.adapter(Rutes::class.java)

        //Definimos la variable rutes dada por el adapter Moshi que pretende ser una instancia de Rutes
        val rutes = adapter.fromJson(json)

        //Con "rutes!!.rutes" declaramos que rutes debe haberse podido leer como
        //una instancia de la clase Rutes, si no dará error. Y accedemos al elemento "rutes" según la estructura del fichero
        //Si tod0 ha ocurrido como esperabamos, podremos asignar la instancia rutes a la variable llistaRutes por ser compatibles.
        llistaRutes = ArrayList(rutes!!.rutes)

        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        setTitle("JSON: Punts d'una ruta")
        setSize(400, 300)
        setLayout(BorderLayout())

        val panell1 = JPanel(FlowLayout())
        val panell2 = JPanel(BorderLayout())
        add(panell1, BorderLayout.NORTH)
        add(panell2, BorderLayout.CENTER)

        var nomsLlistaRutes = arrayListOf<String>()
        // sentències per a omplir l'ArrayList anterior amb el nom de les rutes
        //Obtenemos el nombre de cada ruta accediendo a su atributo nom:
        for (i in 0 until llistaRutes.size) {
            nomsLlistaRutes.add(llistaRutes[i].nom)
        }

        val combo = JComboBox(nomsLlistaRutes.toArray())
        panell1.add(combo)

        panell2.add(JLabel("Llista de punts de la ruta:"), BorderLayout.NORTH)
        val area = JTextArea()
        panell2.add(area)

        combo.addActionListener {
            // accions quan s'ha seleccionat un element del combobox,
            // i que han de consistir en omplir el JTextArea

            var infoPuntos = "" //Aquí almacenaremos el texto a mostrar en el JTextArea

            //referenciamos por comodidad la ruta seleccionada
            val ruta = llistaRutes[combo.getSelectedIndex()]

            //Recopilamos la información de cada punto ayudándonos de los métodos de la clase Ruta:
            for(i in 0 until ruta.size()) {
                infoPuntos += ruta.getPuntNom(i) + " (" + ruta.getPuntLatitud(i) + ", " +
                        "" + ruta.getPuntLongitud(i) + ")\n"
            }
            //Ponemos el texto en el JTextArea
            area.text = infoPuntos

            //Vemos que es mucho más sencillo trabajar con clases habituales de Java/Kotlin que con elementos de DOM
        }
    }
}

fun main(args: Array<String>) {
    EventQueue.invokeLater {
        FinestraJSON().isVisible = true
    }
}