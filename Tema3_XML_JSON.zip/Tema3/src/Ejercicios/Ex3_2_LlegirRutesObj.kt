package Ejercicios

import java.io.EOFException
import java.io.FileInputStream
import java.io.ObjectInputStream

fun main(args: Array<String>) {
    val f = ObjectInputStream(FileInputStream("Rutes.obj"))

    //Como Rutas.obj contiene objetos serilizables, recuperamos los objetos directamente
    try {
        while (true) {
            val ruta = f.readObject() as Ruta
            ruta.mostrarRuta()
        }
    } catch (eof: EOFException) {
        f.close()
    }
}