package Ejercicios

import java.io.DataInputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ObjectOutputStream

fun main(args: Array<String>) {
    //Creamos el flujo de lectura del archivo Rutes.dat
    val f = DataInputStream(FileInputStream("Rutes.dat"))

    //Creamos el flujo de escritura del archivo Rutes.obj
    val f_out = ObjectOutputStream(FileOutputStream("Rutes.obj"))

    //Leemos los datos de Rutes.dat:
    while(f.available() > 0) {
        val nom = f.readUTF()
        val desnivel = f.readInt()
        val desnivelAcum = f.readInt()
        val numPunts = f.readInt()
        //Creamos una lista de puntos en principio vacía
        val llistaPunts: MutableList<PuntGeo> = mutableListOf<PuntGeo>()

        //Instanciamos un objeto Ruta:
        var ruta = Ruta(nom, desnivel, desnivelAcum, llistaPunts)

        //Asignamos los puntos a la Ruta
        for(i in 1..numPunts) {
            val nomPunt = f.readUTF()
            val coord = Coordenades(f.readDouble(), f.readDouble())
            var punt = PuntGeo(nomPunt, coord)
            ruta.addPunt(punt)
        }

        //Mostramos los datos del objeto Ruta recién creado
        ruta.mostrarRuta()

        //Escribimos la Ruta al archivo de salida
        f_out.writeObject(ruta)
    }
    f.close()
    f_out.close()
}
