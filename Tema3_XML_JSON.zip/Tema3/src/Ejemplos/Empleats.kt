package Ejemplos

class Empleats(val empleats: List<Empleat> = listOf<Empleat>())