package Ejemplos

import org.json.JSONTokener
import org.json.JSONObject
import org.json.JSONArray
import java.io.FileReader

fun main(args: Array<String>) {

    val rJson = FileReader("Bicicas.json")

    val arrel = JSONTokener(rJson).nextValue() as JSONArray

    val estacions = arrel.getJSONObject(0).getJSONArray("ocupacion")

    for (e in estacions){
        val est = e as JSONObject
        println("" + est.get("id") + ".- " + est.get("punto") + " (" + est.get("ocupados") + "/" + est.get("puestos") + ")")
    }
}