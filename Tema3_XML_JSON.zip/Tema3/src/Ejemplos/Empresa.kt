package Ejemplos

class Empresa(val empresa: Empleats)