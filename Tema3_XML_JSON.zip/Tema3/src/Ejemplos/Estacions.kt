package Ejemplos

class Estacions(val ocupacion: List<Estacio> = listOf<Estacio>())