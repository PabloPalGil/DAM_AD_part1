package Ejercicios

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

fun main(args: Array<String>) {
    //Ubicamos el directorio raíz:
    val raiz = File.listRoots()[0]

    accederDirectorio(raiz)
}

fun listaDirectorio(file: File){
    val s = "Llista de fitxers i directoris del directori " + file.getCanonicalPath()
    println(s)
    println("-".repeat(s.length))

    var emptyDir = false//variable que indica si el directorio actual está vacío

    //La primera opción es ir al directorio padre (si existe):
    println("0.- Directori pare.")

    if(file.listFiles() == null) {
        emptyDir = true
    } else {
        val files = file.listFiles().sorted() //Creamos un Array de Files de los elementos del directorio actual

        //Listamos los elementos contenidos en el directorio actual
        for(i in 0..files.size - 1){
            if(files[i].isFile())
                println("${i + 1}.- ${files[i].getName()} \t ${files[i].length()}")
            else if(files[i].isDirectory())
                println("${i + 1}.- ${files[i].getName()} \t <Directori>")
        }
    }




    //Indicamos la acción del usuario:
    println("\nIntrodueix un número (-1 per a acabar):")

    var salir = false //variable para controlar la salida del bucle de entrada por teclado

    do {
        //Esperamos la entrada del usuario:
        val input = BufferedReader(InputStreamReader(System.`in`)).readLine().toInt()

        //Controlamos que la entrada sea valida:
        if (input == -1) { //Manejamos el caso -1 de cierre
            println("Tancant...")
            salir = true
        } else if (input == 0) { //Si se elige el 0, se intenta ir al directorio padre:
            if (file.parentFile != null){
                if (file.parentFile.canRead()) {
                    accederDirectorio(file.parentFile)
                    salir = true
                } else {
                    println("No tens permís per accedir a aquest directori.")
                }
            } else {
                println("Estàs a l'arrel.")
            }
        } else if (!emptyDir) {
            val files = file.listFiles().sorted()
            if (input in 1..files.size) {
                //Controlamos que la opción sea un directorio
                if (files[input - 1].isDirectory) {
                    if (files[input - 1].canRead()) {
                        accederDirectorio(files[input - 1])
                        salir = true
                    } else {
                        println("No tens permís per accedir a aquest directori.")
                    }
                } else {
                    println("Tria un directori, no un fitxer.")
                }
            } else {
                println("Tria un número dins del rang.")
            }
        } else {
            println("Tria un número dins del rang.")
        }
    } while (!salir)
}

fun accederDirectorio(file: File){
    listaDirectorio(file)
}

