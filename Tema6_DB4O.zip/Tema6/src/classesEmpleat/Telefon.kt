package classesEmpleat

class Telefon( var mobil : Boolean , var numero: String)