package exercicis

import com.db4o.Db4oEmbedded
import com.db4o.query.Predicate
import util.bd.Ruta

fun main() {
    val bd = Db4oEmbedded.openFile("Rutes.db4o")

    //1 - Consulta con queryByExample():
    val listado = bd.queryByExample<Ruta>(Ruta::class.java)

    //2 - Consulta con Predicate (Native query)
//    val listado = bd.query(object: Predicate<Ruta>() {
//        override
//        fun match(r: Ruta): Boolean {
//            return true
//        }
//    })

    //3 - Consulta con SODA - query.execute()
//    val q = bd.query() //Nodo raíz
//    val node = q.constrain(Ruta::class.java)
//    val listado = q.execute<Ruta>()

    for (r in listado) {
        System.out.println(r.nom + ": " + r.size() + " punts")
    }
    bd.close()
}