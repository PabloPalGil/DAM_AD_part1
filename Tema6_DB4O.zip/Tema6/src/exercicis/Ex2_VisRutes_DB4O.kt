package exercicis

import java.awt.EventQueue
import java.awt.GridLayout
import java.awt.FlowLayout
import javax.swing.JFrame
import javax.swing.JPanel
import javax.swing.BoxLayout
import javax.swing.JComboBox
import javax.swing.JButton
import javax.swing.JTextArea
import javax.swing.JLabel
import javax.swing.JTextField
import javax.swing.JTable
import javax.swing.JScrollPane

import util.bd.Ruta
import util.bd.PuntGeo
import com.db4o.Db4oEmbedded
import kotlin.system.exitProcess

class FinestraComplet : JFrame() {
    var llista = arrayListOf<Ruta>()
    var numActual = 0

    // Declaració de la Base de Dades
    val bd = Db4oEmbedded.openFile("Rutes.db4o")

    val qNom = JTextField(15)
    val qDesn = JTextField(5)
    val qDesnAcum = JTextField(5)
    val punts = JTable(1, 3)
    val primer = JButton(" << ")
    val anterior = JButton(" < ")
    val seguent = JButton(" > ")
    val ultim = JButton(" >> ")
    val tancar = JButton("Tancar")

    //Añadimos el JtextField de Distáncia:
    val qDist = JTextField(10)

    init {
        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        setTitle("JDBC: Visualitzar Rutes Complet")
        setLayout(GridLayout(0, 1))

        val p_prin = JPanel()
        p_prin.setLayout(BoxLayout(p_prin, BoxLayout.Y_AXIS))
        val panell1 = JPanel(GridLayout(0, 2))
        panell1.add(JLabel("Ruta:"))
        qNom.setEditable(false)
        panell1.add(qNom)
        panell1.add(JLabel("Desnivell:"))
        qDesn.setEditable(false)
        panell1.add(qDesn)
        panell1.add(JLabel("Desnivell acumulat:"))
        qDesnAcum.setEditable(false)
        panell1.add(qDesnAcum)

        //Añadimos el panel de Distancia:
        panell1.add(JLabel("Distància:"))
        qDist.setEditable(false)
        panell1.add(qDist)

        panell1.add(JLabel("Punts:"))

        val panell2 = JPanel(GridLayout(0, 1))
        punts.setEnabled(false)
        val scroll = JScrollPane(punts)
        panell2.add(scroll, null)

        val panell5 = JPanel(FlowLayout())
        panell5.add(primer)
        panell5.add(anterior)
        panell5.add(seguent)
        panell5.add(ultim)

        val panell6 = JPanel(FlowLayout())
        panell6.add(tancar)

        add(p_prin)
        p_prin.add(panell1)
        p_prin.add(panell2)
        p_prin.add(panell5)
        p_prin.add(panell6)
        pack()

        primer.addActionListener {
            // instruccions per a situar-se en la primera ruta, i visualitzar-la

            numActual = 0 //Ponemos numActual a 0
            VisRuta() //Actualizamos los datos de la ruta en la GUI
        }
        anterior.addActionListener {
            // instruccions per a situar-se en la ruta anterior, i visualitzar-la

            numActual-- //Restamos 1 a numActual
            VisRuta() //Actualizamos los datos de la ruta en la GUI
        }
        seguent.addActionListener {
            // instruccions per a situar-se en la ruta següent, i visualitzar-la

            numActual++ //Sumamos 1 a numActual
            VisRuta() //Actualizamos los datos de la ruta en la GUI
        }
        ultim.addActionListener {
            // instruccions per a situar-se en l'últim ruta, i visualitzar-la

            numActual = llista.lastIndex //Ponemos numActual en la última posición de llista
            VisRuta() //Actualizamos los datos de la ruta en la GUI
        }
        tancar.addActionListener {
            // instruccions per a tancar la BD i el programa

            bd.close() //Cerramos la conexión con la bd
            exitProcess(0) //Cerramos el programa
        }

        inicialitzar()
        VisRuta()
    }

    fun plenarTaula(ll_punts: MutableList<PuntGeo>) {
        var ll = Array(ll_punts.size) { arrayOfNulls<String>(3) }
        for (i in 0 until ll_punts.size) {
            ll[i][0] = ll_punts.get(i).nom
            ll[i][1] = ll_punts.get(i).coord.latitud.toString()
            ll[i][2] = ll_punts.get(i).coord.longitud.toString()
        }
        val caps = arrayOf("Nom punt", "Latitud", "Longitud")
        punts.setModel(javax.swing.table.DefaultTableModel(ll, caps))
    }

    fun inicialitzar() {
        // instruccions per a inicialitzar llista i numActual

        //En llista ponemos un listado de todas las Rutas de la bd
        val rutasDb4o = bd.queryByExample<Ruta>(Ruta::class.java)

        for (r in rutasDb4o)
            llista.add(r)

        numActual = 0 //Ponemos numActual a 0 por si acaso (aunque debería ser 0 ya)
    }

    fun VisRuta() {
        // instruccions per a visualitzar la ruta actual (l'índex el tenim en numActual

        //Recabamos la información de la ruta numActual-ésima y lo vamos mostrando en la GUI:
        qNom.text = llista[numActual].nom //El nombre de la ruta
        qDesn.text = llista[numActual].desnivell.toString() //El desnivel
        qDesnAcum.text = llista[numActual].desnivellAcumulat.toString() //El desnivell acumulat

        //Del detalle de los puntos de la ruta se encarga la función plenarTaula(), que recibe un listado de PuntGeo
        plenarTaula(llista[numActual].llistaDePunts)

        //PARTE VOLUNTARIA
        //Añadimos el cálculo de la distancia de la ruta punto a punto:
        var dist = 0.0 //Inicializamos a 0

        //Por comodidad, referenciamos la ruta actual a r
        val r = llista[numActual]

        //Recorremos la lista de puntos de la ruta desde el índice 1 (segundo elemento) hasta el final
        for(i in 1..r.llistaDePunts.lastIndex){
            dist += Dist(r.getPuntLatitud(i - 1), r.getPuntLatitud(i - 1), r.getPuntLatitud(i), r.getPuntLongitud(i))
        }

        //Mostramos la distancia en km:
        val distString = String.format("%.2f", dist * 0.001)
        qDist.text = "$distString km"

        ActivarBotons()
    }

    fun ActivarBotons() {
        // instruccions per a activar o desactivar els botons de moviment ( setEnabled(Boolean) )

        when (numActual) {
            0 -> {
                primer.setEnabled(false)
                anterior.setEnabled(false)
                seguent.setEnabled(true)
                ultim.setEnabled(true)
            }
            llista.lastIndex -> {
                primer.setEnabled(true)
                anterior.setEnabled(true)
                ultim.setEnabled(false)
                seguent.setEnabled(false)
            }
        }
    }

}

fun main(args: Array<String>) {
    EventQueue.invokeLater {
        FinestraComplet().isVisible = true
    }
}

//Mét0do para calcular la distancia en km entre 2 puntos geográficos
fun Dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {

    val R = 6378.137 // Radi de la Tierra en km
    val dLat = rad(lat2 - lat1)
    val dLong = rad(lon2 - lon1)

    val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLong / 2) * Math.sin(dLong / 2)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    val d = R * c
    return Math.round(d*100.0)/100.0
}

//Mét0do que recibe un valor en grados y lo devuelve en radianes
fun rad(x: Double): Double {
    return x * Math.PI / 180
}