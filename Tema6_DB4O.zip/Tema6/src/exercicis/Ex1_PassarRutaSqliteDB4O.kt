package exercicis

import com.db4o.Db4oEmbedded
import util.bd.GestionarRutesBD
import util.bd.Ruta

fun main() {
    //Instanciamos el gestor de Rutas sqlite
    val gRutes = GestionarRutesBD()

    //Almacenamos las rutas en un ArrayList
    val listaRutas: ArrayList<Ruta> = gRutes.llistat()

    //Conectamos (y creamos si no existe) con la bd de db4o
    val bd = Db4oEmbedded.openFile("Rutes.db4o")

    //Para cada ruta:
    for (r in listaRutas){
        bd.store(r) //Guardamos la Ruta en la bd
    }

    //Cerramos la conexión con la bd
    bd.close()
}