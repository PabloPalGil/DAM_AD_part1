package util.bd

import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.sql.Statement

class GestionarRutesBD{
    //Propiedad de la conexión sql
    private var con: Connection = DriverManager.getConnection("jdbc:sqlite:Rutes.sqlite")

    //Ponemos el código que crea la conexión y las tablas en un bloque init para que
    //se ejecute inmediatamente después del constructor
    init{
        try {
            //Creamos el statement (al no ser con parámetros, implementamos la sentencia SQL en su ejecución):
            val st = con.createStatement()

            println("Conexión con Rutes.sqlite realizada con éxito")

            //Definimos la sentencia SQL
            val sentSQL = "CREATE TABLE IF NOT EXISTS 'RUTES'(" +
                    "num_r INTEGER CONSTRAINT cp_rut PRIMARY KEY, " +
                    "nom_r TEXT, " +
                    "desn INTEGER, " +
                    "desn_ac INTEGER" +
                    ");" +
                    "CREATE TABLE IF NOT EXISTS 'PUNTS'(" +
                    "num_r INTEGER CONSTRAINT ce_punts_rutes references RUTES(num_r), " +
                    "num_p INTEGER, " +
                    "nom_p TEXT, " +
                    "latitud REAL, " +
                    "longitud REAL," +
                    "CONSTRAINT cp_punts_rutes PRIMARY KEY (num_r, num_p)" +
                    ");"

            //Ejecutamos la sentencia:
            st.executeUpdate(sentSQL)

        } catch (e: SQLException) {
            println("Error: ${e.message}")
        }
    }


    //Método que cierra la conexión
    fun close(){
        try {
            if (con != null && !con.isClosed()) {
                con.close()
            }
        } catch (ex: SQLException) {
            throw ex
        } finally{
            System.exit(0) //Cerramos la aplicación
        }
    }


    //método que inserta Rutas en la BD:
    fun inserir(r: Ruta) {
        var st1: Statement? = null
        var st2: Statement? = null
        var st3: Statement? = null

        try{
            //Vamos insertando la información desglosada por columnas en cada tabla de la bbdd:
            //Tabla RUTES:
            //Columna num_r (clave principal, INTEGER)
            var numR = 1
            //creamos el statement paar obtener el num_r más alto existente
            st1 = con.createStatement()
            //guardamos el resultado de la consulta:
            val rs1 = st1.executeQuery("SELECT MAX(num_r) FROM RUTES;")
            //Comprobamos que hubiera alguna ruta:
            if (rs1.next())
                numR = rs1.getInt(1) + 1

            //Definimos la sentencia SQL, que para mayor comodidad será con parámetros:
            //Al ser con parámetros, definimos la sentencia en el momento de su definición:
            st2 = con.prepareStatement("INSERT INTO RUTES VALUES (?, ?, ?, ?);")
            //Definimos los parámetros
            st2.setInt(1, numR)
            st2.setString(2, r.nom)
            st2.setInt(3, r.desnivell!!)
            st2.setInt(4, r.desnivellAcumulat!!)

            //Comprobamos que la sintaxis es correcta:
            //println(st2)

            //Ejecutamos la sentencia:
            st2.executeUpdate()

            //Insertamos cada punto de cada ruta:
            for(j in 0..r.llistaDePunts.lastIndex){
                //Tabla PUNTS:
                //Columna num_p (INTEGER)
                val numP = j + 1

                //Columna nom_p (TEXT)
                val nomP = r.llistaDePunts[j].nom

                //Columna latitud (REAL)
                val lat = r.llistaDePunts[j].coord.latitud

                //Columna longitud (REAL)
                val long = r.llistaDePunts[j].coord.longitud

                st3 = con.prepareStatement("INSERT INTO PUNTS (num_r, num_p, nom_p, latitud, longitud)" +
                        "VALUES (?, ?, ?, ?, ?);")

                //Parámetros de la tabla PUNTS
                st3.setInt(1, numR)
                st3.setInt(2, numP)
                st3.setString(3, nomP)
                st3.setDouble(4, lat)
                st3.setDouble(5, long)

                //Comprobamos que la sintaxis es correcta:
                //println(st3)

                //Ejecutamos la sentencia:
                st3.executeUpdate()
            }

            println("Ruta ${r.nom} añadida con éxito.")
        } catch(e: SQLException) {
            println("Error: ${e.message}")
        } finally {
            //Cerramos la sentencias:
            if (st1 != null && !st1.isClosed) {
                st1.close()
            }
            if (st2 != null && !st2.isClosed) {
                st2.close()
            }
            if (st3 != null && !st3.isClosed) {
                st3.close()
            }
        }
    }


    //Método que devuelve la Ruta cuyo número se pasa como parámetro o null si no existe
    fun buscar(i: Int): Ruta? {
        //Creamos un objeto Ruta
        var ruta: Ruta? = null
        var st1: Statement? = null
        var st2: Statement? = null

        try{
            //Definimos la sentencia SQL con parámetros para encontrar la ruta solicitada:
            st1 = con.prepareStatement("SELECT * FROM RUTES WHERE num_r = ?;")
            //Definimos el parámetro
            st1.setInt(1, i)

            //Almacenamos los resultados:
            val rs = st1.executeQuery()

            //Comprobamos si existe la ruta, devolverá un next():
            if(rs.next()) {
                println("Ruta $i encontrada.")

                //Buscamos la lista de puntos de la ruta en una nueva sentencia
                st2 = con.prepareStatement("SELECT * FROM PUNTS WHERE num_r = ?;")
                //Definimos el parámetro
                st2.setInt(1, i)

                //Almacenamos los resultados:
                val rs2 = st2.executeQuery()

                //Creamos la variable donde guardaremos los puntos (vacía por defecto)
                var listaPuntos: MutableList<PuntGeo> = ArrayList()

                //Recorremos y guardamos cada punto
                while (rs2.next()) {
                    //Aquí guardamos cada punto
                    val punt = PuntGeo(rs2.getString(3), Coordenades(rs2.getDouble(4), rs2.getDouble(5)))
                    //Lo añadimos a la lista de puntos:
                    listaPuntos.add(punt)
                }

                //Procedemos a crear nuestro objeto Ruta:
                ruta = Ruta(rs.getString(2), rs.getInt(3), rs.getInt(4), listaPuntos)

            } else{
                println("No se encuentra la ruta $i.")
            }
        } catch (e: SQLException) {
            println("Error: ${e.message}")
        } finally {
            if (st2 != null && !st2.isClosed) {
                st2.close()
            }
            if (st1 != null && !st1.isClosed) {
                st1.close()
            }
            //Devolvemos ruta (que será null si no se ha encontrado en la BD)
            return ruta
        }
    }


    //Método que devuelve un ArrayList de Ruta con todas las rutas de la BD
    fun llistat(): ArrayList<Ruta> {
        //Inicializamos la lista de Rutas vacía
        var listaRutas: ArrayList<Ruta> = ArrayList()
        var st: Statement? = null

        try{
            //Ejecutamos una sentencia sencilla para obtener un listado de todos los numeros de ruta
            st = con.createStatement()
            val rs = st.executeQuery("SELECT num_r FROM RUTES;")

            //Pasamos cada numero de ruta por el méttodo buscar para obtener un objeto Ruta de cada una:
            while (rs.next()){
                listaRutas.add(buscar(rs.getInt(1))!!) //Forzamos la confianza de que la Ruta no será null
            }
        } catch (e: SQLException) {
            println("Error: ${e.message}")
        } finally {
            //Cerramos la sentencia y devolvemos el listado de Rutas
            if (st != null && !st.isClosed) {
                st.close()
            }
            return listaRutas
        }
    }


    //Método que elimina la ruta con el número pasado como parámetro de la BD
    fun esborrar(i: Int){
        var st: Statement? = null
        var st2: Statement? = null

        try{
            //Definimos la sentencia SQL con parámetros para encontrar la ruta solicitada, si existe:
            st = con.prepareStatement("SELECT * FROM RUTES WHERE num_r = ?;")
            //Definimos el parámetro
            st.setInt(1, i)

            //Almacenamos los resultados:
            val rs = st.executeQuery()

            //Comprobamos si existe la ruta, devolverá un next():
            if(rs.next()) {
                //Creamos una sentencia sql para eliminar los datos de la tabla PUNTS la ruta:
                val st2 = con.prepareStatement("DELETE FROM PUNTS WHERE num_r = ?;")
                st2.setInt(1, i)
                st2.executeUpdate()

                //Creamos una sentencia sql para eliminar los datos de la tabla RUTES la ruta:
                val st3 = con.prepareStatement("DELETE FROM RUTES WHERE num_r = ?;")
                st3.setInt(1, i)
                st3.executeUpdate()

                st2.close()
                st3.close()

                println("Ruta $i eliminada de la BD.")
            } else{
                println("No se encuentra la ruta $i.")
            }
        } catch (e: SQLException) {
            println("Error: ${e.message}")
        } finally {
            //Cerramos las sentencias
            if (st != null && !st.isClosed) {
                st.close()
            }
            if (st2 != null && !st2.isClosed) {
                st2.close()
            }
        }
    }
}